CREATE TABLE IF NOT EXISTS access_requests (
 request_id text PRIMARY KEY, payload_sha256 char(64) NOT NULL,
 payload jsonb NOT NULL, status text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS access_items (
 request_id text NOT NULL REFERENCES access_requests(request_id),
 app text NOT NULL, role text NOT NULL, status text NOT NULL,
 attempts integer NOT NULL DEFAULT 0, next_attempt_at timestamptz,
 lease_until timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(request_id,app,role)
);
CREATE INDEX IF NOT EXISTS access_items_queue_idx ON access_items(status,next_attempt_at,created_at);
