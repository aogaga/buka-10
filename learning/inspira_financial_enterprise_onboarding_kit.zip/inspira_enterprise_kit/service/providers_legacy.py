"""Freshservice-driven, allowlisted multi-application access provisioning.

Security boundary: only trusted workload identity can call this endpoint; Freshservice
approval is revalidated server-side before any mutation. See README for deployment.
"""
import asyncio
import json
import logging
import os
import re
import hashlib
import time
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal
from urllib.parse import quote

import httpx
import jwt
from jwt import PyJWKClient
import psycopg
from psycopg.rows import dict_row
from azure.identity.aio import ClientSecretCredential, DefaultAzureCredential
from fastapi import Depends, FastAPI, Header, HTTPException, status
from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("provisioner")

class User(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: EmailStr
    entra_object_id: str | None = None
    github_username: str | None = None
    sonarqube_login: str | None = None

class Application(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: Literal["azure_devops", "github", "sonarqube"]
    role: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,40}$")

class Request(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")
    user: User
    applications: list[Application] = Field(min_length=1, max_length=50)

    @model_validator(mode="after")
    def unique_apps(self):
        if len({a.name for a in self.applications}) != len(self.applications):
            raise ValueError("Only one entitlement per application is permitted")
        return self

class ProvisioningError(Exception):
    pass

class Pending(Exception):
    pass

class HttpClient:
    def __init__(self, client: httpx.AsyncClient): self.client = client

    async def call(self, method, url, *, headers=None, json_body=None, data=None, auth=None, params=None):
        for attempt in range(4):
            try:
                r = await self.client.request(method, url, headers=headers, json=json_body,
                                              data=data, auth=auth, params=params)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                # Writes may have succeeded. Only retry when the operation is safely idempotent.
                raise ProvisioningError("Transport failure; reconcile before retry") from exc
            if r.status_code in (429, 502, 503, 504):
                if attempt < 3:
                    wait = r.headers.get("Retry-After", "")
                    delay = min(float(wait), 20) if wait.isdigit() else min(2 ** attempt, 8)
                    await asyncio.sleep(delay)
                    continue
            if r.status_code >= 400:
                raise ProvisioningError(f"Provider HTTP {r.status_code}; inspect secured provider logs")
            return r
        raise ProvisioningError("Provider temporarily unavailable")

async def freshservice_approved(http: HttpClient, req: Request):
    """Fail-closed approval authority: customer-operated verifier must check ticket,
    requester identity, exact requested entitlements, approvals and revocation.
    A positive response is trusted ONLY from an authenticated internal service.
    """
    endpoint = os.environ.get("APPROVAL_VERIFIER_URL", "")
    secret = os.environ.get("APPROVAL_VERIFIER_TOKEN", "")
    if not endpoint.startswith("https://") or not secret:
        raise HTTPException(503, "Approval verifier not configured")
    payload = req.model_dump(mode="json")
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    try:
        response = await http.call("POST", endpoint, headers={"Authorization": f"Bearer {secret}"},
                                   json_body={"request": payload, "request_sha256": digest})
        data = response.json()
    except (ProvisioningError, ValueError) as exc:
        raise HTTPException(503, "Approval verification unavailable") from exc
    if data.get("approved") is not True or data.get("request_sha256") != digest or data.get("ticket_id") != req.request_id:
        raise HTTPException(403, "Approval missing or request does not match approved scope")
    return digest

async def azure_devops(http: HttpClient, user: User, spec: dict):
    if not user.entra_object_id: raise ProvisioningError("entra_object_id required")
    group_id = spec["entra_group_id"]
    cred = DefaultAzureCredential(exclude_interactive_browser_credential=True)
    try:
        token = await cred.get_token("https://graph.microsoft.com/.default")
    finally:
        await cred.close()
    h = {"Authorization": f"Bearer {token.token}"}
    member = quote(user.entra_object_id, safe="")
    group = quote(group_id, safe="")
    check = await http.client.get(f"https://graph.microsoft.com/v1.0/groups/{group}/members/{member}/$ref", headers=h)
    if check.status_code == 204 or check.status_code == 200: return "already_present"
    if check.status_code != 404: raise ProvisioningError(f"Graph membership check HTTP {check.status_code}")
    try:
        await http.call("POST", f"https://graph.microsoft.com/v1.0/groups/{group}/members/$ref",
                        headers=h, json_body={"@odata.id": f"https://graph.microsoft.com/v1.0/directoryObjects/{member}"})
    except ProvisioningError as exc:
        # Graph returns 400 if already a member in some cases; do not suppress other errors.
        raise exc
    return "granted"

async def github(http: HttpClient, user: User, spec: dict):
    if not user.github_username: raise ProvisioningError("github_username required")
    token = os.environ["GITHUB_TOKEN"]
    h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
         "X-GitHub-Api-Version": os.getenv("GITHUB_API_VERSION", "2022-11-28")}
    org, team, username = quote(spec["org"], safe=""), quote(spec["team_slug"], safe=""), quote(user.github_username, safe="")
    # PUT is idempotent, but GitHub may return pending invitation rather than active access.
    r = await http.call("PUT", f"https://api.github.com/orgs/{org}/teams/{team}/memberships/{username}",
                        headers=h, json_body={"role": spec.get("membership_role", "member")})
    return "pending" if r.json().get("state") == "pending" else "granted"

async def sonarqube(http: HttpClient, user: User, spec: dict):
    if not user.sonarqube_login: raise ProvisioningError("sonarqube_login required")
    base = os.environ["SONARQUBE_URL"].rstrip("/")
    token = os.environ["SONARQUBE_TOKEN"]
    # This adapter targets SonarQube Server; Cloud and IdP-synced groups require a separate adapter.
    r = await http.call("GET", f"{base}/api/user_groups/users",
                        params={"name": spec["group"], "selected": "selected", "ps": 500},
                        auth=(token, ""))
    users = r.json().get("users", [])
    if any(x.get("login") == user.sonarqube_login for x in users): return "already_present"
    await http.call("POST", f"{base}/api/user_groups/add_user", auth=(token, ""),
                    data={"name": spec["group"], "login": user.sonarqube_login})
    return "granted"

PROVIDERS = {"azure_devops": azure_devops, "github": github, "sonarqube": sonarqube}

_jwks = None
async def authenticate(authorization: str = Header(default="")):
    """Validate caller's JWT and exact service principal; fail closed."""
    global _jwks
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Bearer token required")
    issuer, audience, jwks_url, client_id = (os.getenv(k) for k in
        ("OIDC_ISSUER", "OIDC_AUDIENCE", "OIDC_JWKS_URL", "ALLOWED_CLIENT_ID"))
    if not all((issuer, audience, jwks_url, client_id)) or not jwks_url.startswith("https://"):
        raise HTTPException(503, "OIDC authentication not configured")
    try:
        if _jwks is None: _jwks = PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=300)
        token = authorization[7:]
        key = _jwks.get_signing_key_from_jwt(token)
        claims = jwt.decode(token, key.key, algorithms=["RS256"], audience=audience,
                            issuer=issuer, options={"require": ["exp", "iat", "iss", "aud"]}, leeway=30)
        if claims.get("azp", claims.get("appid")) != client_id:
            raise HTTPException(403, "Caller application not permitted")
        return claims
    except HTTPException: raise
    except (jwt.PyJWTError, ValueError) as exc:
        raise HTTPException(401, "Invalid caller token") from exc

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = HttpClient(httpx.AsyncClient(timeout=httpx.Timeout(15, connect=5)))
    yield
    await app.state.http.client.aclose()

app = FastAPI(title="Freshservice Enterprise Provisioner", version="1.0", lifespan=lifespan)

@app.get("/healthz")
async def healthz(): return {"status": "ok"}

def ledger_connection():
    dsn = os.getenv("DATABASE_URL")
    if not dsn: raise HTTPException(503, "Durable ledger database not configured")
    return psycopg.connect(dsn, row_factory=dict_row, connect_timeout=5)

@app.post("/v1/provision", dependencies=[Depends(authenticate)])
async def provision(req: Request):
    http = app.state.http
    # Do not use an approval flag in the submitted payload.
    digest = await freshservice_approved(http, req)
    roles = json.loads(Path(os.environ.get("ROLE_CONFIG", "config.json")).read_text())["roles"]
    # One transaction-level advisory lock per Freshservice request prevents concurrent replays.
    # Each provider result is committed independently to allow safe recovery.
    try:
        with ledger_connection() as db:
            with db.cursor() as cur:
                cur.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))", (req.request_id,))
                cur.execute("SELECT payload_sha256 FROM requests WHERE request_id=%s", (req.request_id,))
                existing = cur.fetchone()
                if existing and existing["payload_sha256"] != digest:
                    raise HTTPException(409, "Request ID already used for a different payload")
                if not existing:
                    cur.execute("INSERT INTO requests(request_id,payload_sha256) VALUES (%s,%s)", (req.request_id,digest))
                results=[]
                for item in req.applications:
                    cur.execute("SELECT status FROM entitlements WHERE request_id=%s AND app=%s AND role=%s",
                                (req.request_id,item.name,item.role))
                    old=cur.fetchone()
                    if old and old["status"] in ("granted","already_present","pending"):
                        outcome=old["status"]
                    else:
                        spec=roles.get(item.name,{}).get(item.role)
                        if not spec:
                            outcome="rejected"
                        else:
                            try:
                                outcome=await PROVIDERS[item.name](http,req.user,spec)
                            except (ProvisioningError, KeyError, ValueError) as exc:
                                log.warning("provider_error request=%s app=%s type=%s",req.request_id,item.name,type(exc).__name__)
                                outcome="needs_reconciliation"
                        cur.execute("""INSERT INTO entitlements(request_id,app,role,status,updated_at)
                            VALUES (%s,%s,%s,%s,now()) ON CONFLICT(request_id,app,role)
                            DO UPDATE SET status=excluded.status,updated_at=now()""",
                            (req.request_id,item.name,item.role,outcome))
                    results.append({"application":item.name,"role":item.role,"status":outcome})
                # Transaction remains open for serialization; ensure DB/HTTP timeouts and a
                # single writer per request. Use queue workers for larger production loads.
        complete=all(r["status"] in ("granted","already_present") for r in results)
        return {"request_id":req.request_id,"overall_status":"completed" if complete else "action_required", "results":results}
    except psycopg.Error as exc:
        log.error("database_error request=%s type=%s",req.request_id,type(exc).__name__)
        raise HTTPException(503,"Provisioning ledger unavailable") from exc
