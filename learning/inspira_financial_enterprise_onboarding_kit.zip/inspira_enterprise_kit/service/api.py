"""Authenticated ingestion API. Never provisions within the request thread."""
import hashlib
import json
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException
import psycopg
from psycopg.rows import dict_row
from .providers_legacy import Request, authenticate


def connect():
    return psycopg.connect(os.environ['DATABASE_URL'], row_factory=dict_row, connect_timeout=5)


def canonical(request):
    payload = request.model_dump(mode='json')
    return json.dumps(payload, sort_keys=True, separators=(',', ':'))


app = FastAPI(title='Inspira Financial Access Orchestrator', version='2.0')


@app.get('/healthz')
def health():
    return {'status': 'alive'}


@app.get('/readyz')
def ready():
    try:
        with connect() as db:
            db.execute('SELECT 1')
        return {'status': 'ready'}
    except psycopg.Error:
        raise HTTPException(503, 'Database unavailable')


@app.post('/v2/requests', status_code=202, dependencies=[Depends(authenticate)])
def submit(request: Request):
    data = canonical(request)
    digest = hashlib.sha256(data.encode()).hexdigest()
    try:
        with connect() as db:
            with db.cursor() as cur:
                cur.execute('''INSERT INTO access_requests(request_id,payload_sha256,payload,status)
                    VALUES (%s,%s,%s::jsonb,'queued') ON CONFLICT DO NOTHING''',
                    (request.request_id,digest,data))
                cur.execute('SELECT payload_sha256,status FROM access_requests WHERE request_id=%s', (request.request_id,))
                row = cur.fetchone()
                if row['payload_sha256'] != digest:
                    raise HTTPException(409,'Request ID conflicts with a different payload')
                for a in request.applications:
                    cur.execute('''INSERT INTO access_items(request_id,app,role,status)
                        VALUES (%s,%s,%s,'queued') ON CONFLICT DO NOTHING''',
                        (request.request_id,a.name,a.role))
        return {'request_id':request.request_id,'status':row['status'],'status_url':f'/v2/requests/{request.request_id}'}
    except psycopg.Error as e:
        raise HTTPException(503,'Ledger unavailable') from e


@app.get('/v2/requests/{request_id}', dependencies=[Depends(authenticate)])
def status(request_id: str):
    try:
        with connect() as db:
            req=db.execute('SELECT request_id,status,created_at FROM access_requests WHERE request_id=%s',(request_id,)).fetchone()
            if not req: raise HTTPException(404,'Request not found')
            items=db.execute('SELECT app,role,status,attempts,updated_at FROM access_items WHERE request_id=%s ORDER BY app',(request_id,)).fetchall()
        return {'request_id':req['request_id'],'status':req['status'],'items':items}
    except psycopg.Error as e:
        raise HTTPException(503,'Ledger unavailable') from e
