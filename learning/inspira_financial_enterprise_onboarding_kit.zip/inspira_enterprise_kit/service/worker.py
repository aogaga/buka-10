"""DB-backed durable work dispatcher. Ambiguous writes require reconciliation, never blind replay."""
import asyncio
import json
import logging
import os
import signal
from datetime import datetime, timezone
from pathlib import Path
import httpx
import psycopg
from psycopg.rows import dict_row
from .providers_legacy import Request, HttpClient, PROVIDERS, ProvisioningError, freshservice_approved
from .api import connect

log=logging.getLogger('inspira.worker')
TERMINAL=('granted','already_present','rejected','pending','needs_reconciliation')


def claim():
    with connect() as db:
        with db.cursor() as cur:
            cur.execute('''SELECT i.request_id,i.app,i.role,r.payload
                FROM access_items i JOIN access_requests r USING(request_id)
                WHERE i.status='queued' AND (i.next_attempt_at IS NULL OR i.next_attempt_at<=now())
                ORDER BY i.created_at FOR UPDATE OF i SKIP LOCKED LIMIT 1''')
            job=cur.fetchone()
            if not job: return None
            cur.execute('''UPDATE access_items SET status='running',attempts=attempts+1,
                lease_until=now()+interval '3 minutes',updated_at=now()
                WHERE request_id=%s AND app=%s AND role=%s''',(job['request_id'],job['app'],job['role']))
            return job


def finalize(job,status):
    with connect() as db:
        db.execute('''UPDATE access_items SET status=%s,lease_until=NULL,updated_at=now()
            WHERE request_id=%s AND app=%s AND role=%s''',(status,job['request_id'],job['app'],job['role']))
        db.execute('''UPDATE access_requests SET status=CASE
            WHEN EXISTS(SELECT 1 FROM access_items WHERE request_id=%s AND status IN ('queued','running')) THEN 'processing'
            WHEN EXISTS(SELECT 1 FROM access_items WHERE request_id=%s AND status NOT IN ('granted','already_present')) THEN 'action_required'
            ELSE 'completed' END,updated_at=now() WHERE request_id=%s''',
            (job['request_id'],job['request_id'],job['request_id']))


async def execute(job,http,roles):
    req=Request.model_validate(job['payload'])
    # Approval is checked at execution time; any outage or mismatch fails closed.
    try:
        await freshservice_approved(http,req)
    except Exception:
        log.warning('Approval unavailable or denied for %s',job['request_id'])
        return 'approval_required'
    spec=roles.get(job['app'],{}).get(job['role'])
    if not spec: return 'rejected'
    try:
        return await PROVIDERS[job['app']](http,req.user,spec)
    except (ProvisioningError,KeyError,ValueError,httpx.HTTPError) as exc:
        log.warning('Provisioning requires reconciliation request=%s app=%s error_type=%s',job['request_id'],job['app'],type(exc).__name__)
        return 'needs_reconciliation'


async def run():
    logging.basicConfig(level=os.getenv('LOG_LEVEL','INFO'))
    roles=json.loads(Path(os.environ.get('ROLE_CONFIG','/app/roles.json')).read_text())['roles']
    async with httpx.AsyncClient(timeout=httpx.Timeout(20,connect=5)) as client:
        http=HttpClient(client)
        while True:
            job=await asyncio.to_thread(claim)
            if job is None:
                await asyncio.sleep(2)
                continue
            result=await execute(job,http,roles)
            await asyncio.to_thread(finalize,job,result)


if __name__=='__main__':
    asyncio.run(run())
