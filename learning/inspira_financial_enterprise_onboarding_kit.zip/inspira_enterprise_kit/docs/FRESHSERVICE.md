# Freshservice integration contract

Create a service catalog item for Developer Access. Collect employee corporate email, identity references, requested application/role array, justification and manager/application owner approvals. An authenticated integration bridge (not Freshservice client-side JavaScript) converts the approved request into the API contract.

Workflow: request created -> manager + resource owner approvals -> integration bridge retrieves ticket and approved scope -> POST /v2/requests -> persist returned ID -> periodically GET /v2/requests/{id} -> write individual app outcomes and exceptions back to Freshservice -> resolve only when all entitlements are confirmed granted/already present. Preserve pending/needs_reconciliation as actionable states.

Important: Freshservice field placeholders and webhook authentication differ by tenant/configuration. Validate against the actual tenant; never hardcode a ticket's `approved` boolean in a webhook payload as authorization.
