# Operations and incident runbook

## Daily checks
- Alert on queued backlog age, running lease expiry, approval verifier errors, reconciliation items, API 5xx, provider throttling, and status-update lag.
- Review privileged group mapping changes and service credential rotation.
- Audit request ID, actor, approved entitlement scope, application outcome and correlation ID without logging tokens.

## Recovery
1. Locate request by Freshservice ID using authenticated status endpoint.
2. For `needs_reconciliation` or expired `running`, inspect actual provider membership using read-only credentials before any replay.
3. If membership exists, record verified outcome with an audited operator workflow (not included in this reference).
4. If absent, require a controlled retry after verifying approvals remain valid.
5. For `pending`, wait for external invitation acceptance or SSO sync; do not report granted.
6. For `approval_required`, resolve verifier availability/authorization; do not override by request flag.

## Security gates before go-live
- Threat model; identity and group ownership; separation of duties; access reviews; conditional access.
- Freshservice ticket authenticity, approval state and request scope independently checked.
- Least-privilege service identities, scoped GitHub App where possible, Key Vault rotation, audit retention.
- Private endpoints, egress allowlists, certificate validation, rate limits, monitoring, SAST/SCA/container scans.
- Concurrency/load tests, rollback policy, failure injection, disaster recovery exercises, provider API contract tests.
