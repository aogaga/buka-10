# Architecture and extension guide

API and workers scale independently. Requests are immutable by request_id; different payloads under the same ID are rejected. Entitlement jobs are independent and selected with `FOR UPDATE SKIP LOCKED`.

To add an application: (1) define a provider adapter with read-before-write and explicit pending semantics, (2) extend the request schema allowlist, (3) add approved role mappings, (4) add mocked failure/idempotency tests, (5) confirm least-privilege provider identity, (6) update monitoring and reconciliation runbooks.

For production-scale traffic, replace polling database jobs with a broker and dead-letter queue, use transactional outbox to publish reliably, implement bounded per-provider concurrency and rate limits, and add distributed tracing and per-tenant quotas.
