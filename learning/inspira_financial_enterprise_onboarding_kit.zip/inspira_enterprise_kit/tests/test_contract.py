import pytest
from pydantic import ValidationError
from service.providers_legacy import Request
from service.api import canonical

BASE={'request_id':'FS-123','user':{'email':'someone@example.com'},'applications':[{'name':'github','role':'developer'}]}

def test_valid_array():
    assert len(Request.model_validate(BASE).applications)==1

def test_reject_duplicate_app():
    with pytest.raises(ValidationError):
        Request.model_validate({**BASE,'applications':BASE['applications']*2})

def test_reject_unknown_app():
    with pytest.raises(ValidationError):
        Request.model_validate({**BASE,'applications':[{'name':'unknown','role':'admin'}]})

def test_canonical_stable():
    r=Request.model_validate(BASE)
    assert canonical(r)==canonical(r)
