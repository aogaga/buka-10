# Inspira Financial — Enterprise Access Onboarding Kit (reference implementation)

**Status: reference implementation, NOT production certified.** This package upgrades the earlier synchronous example to an authenticated API + PostgreSQL-backed work dispatcher with independent per-application outcomes. It has not been tested against Inspira Financial infrastructure.

## Components

- `service/api.py`: authenticated intake, canonical payload hashing, duplicate rejection, status endpoint.
- `service/worker.py`: PostgreSQL `SKIP LOCKED` work claiming, approval revalidation, per-app execution, outcome recording.
- `service/providers_legacy.py`: adapters for Azure DevOps via Microsoft Graph groups, GitHub teams, SonarQube Server groups; request schemas and JWT verifier. **Legacy filename is for compatibility, not a second API to run.**
- `deploy/schema.sql`: durable request/entitlement tables.
- `deploy/compose.yaml`: development-only PostgreSQL/API/worker setup.
- `examples/roles.json`: role-to-resource allowlist (replace placeholder IDs).
- `examples/request.json`: sample Freshservice payload.
- `docs/`: runbooks, security boundaries and workflow mapping.

## Request contract

POST `/v2/requests` with `Authorization: Bearer <service-token>` and the JSON in `examples/request.json`. Each application is an object with `name` and `role`. Currently supported provider identifiers: `azure_devops`, `github`, `sonarqube`. Max 50 distinct apps per request; because only 3 adapters exist, a request currently supports at most 3. For multiple resources in one provider, evolve the schema to use `entitlement_key` and explicitly approved resource scopes rather than duplicate application entries.

202 response: `{"request_id":"FS-10452","status":"queued","status_url":"/v2/requests/FS-10452"}`. Poll `GET /v2/requests/FS-10452` with the same authenticated service identity. Status is eventually consistent.

## Local development (never use sample secrets in production)

1. Copy `.env.example` to `.env`, configure values; `POSTGRES_PASSWORD` must match `DATABASE_URL`.
2. Replace `examples/roles.json` placeholders with actual approved groups and team slugs.
3. `docker compose -f deploy/compose.yaml up --build`.
4. Obtain a JWT from an authorized client registered with Entra ID and call the API.
5. Provide an internal **approval verifier** at `APPROVAL_VERIFIER_URL`: it must independently fetch the Freshservice ticket, verify all required approvals, validate user and exact entitlements, and respond `{"approved":true,"ticket_id":"FS-10452","request_sha256":"<sha256 of canonical request>"}`. Never trust approval fields in request JSON.
6. Run `python -m pytest tests` after installing requirements.

## Architecture caveats / production blockers

- **Approval verifier is an interface only**; this package does not implement a trusted Freshservice approval connector. Until it is configured, provisioning fails closed.
- **Freshservice ticket updates and notifications are not implemented**. Add a dedicated outbound integration using a scoped credential, bounded retries and outbox.
- **Worker crash recovery is not automated**. A `running` item whose lease expires must be investigated/reconciled; do not blindly replay unknown writes. Add a reconciliation operator or provider-specific read-before-retry workflow.
- **No automatic retry for ambiguous writes**. Transport errors may occur after a provider successfully applied access. Items are marked `needs_reconciliation`.
- **No RBAC/tenant authorization for status lookup beyond service identity**. Add per-client authorization if serving multiple business units.
- **No queue broker**. PostgreSQL `SKIP LOCKED` is a durable database work queue suitable for controlled scale, not an Azure Service Bus replacement; size and load-test it.
- **No deployment IaC, HA, autoscaling, SIEM integration, or full integration tests**. Compose is development-only.
- **Role mapping is static** and must be reviewed and versioned through change control.
- **SSO-synchronized groups** must be managed through their identity provider; the SonarQube adapter is for SonarQube Server local groups, not SonarQube Cloud.
- Azure DevOps access via Entra groups requires correct existing group integration and licensing. GitHub memberships can be pending invitations.
- HTTP client currently retries some provider 429/5xx responses; verify each operation's idempotency and provider semantics before production.
- Secrets must come from Azure Key Vault/workload identity, not `.env` in production; restrict outbound destinations, private networking and TLS.
- Encrypt sensitive request payloads at rest, enforce retention, audit access, and minimize PII in logs.

## Recommended target production design

Freshservice approved request -> trusted Freshservice bridge -> API Management / WAF -> ingestion API -> durable broker (Azure Service Bus) -> workers -> provider APIs -> event/outbox -> Freshservice updates + SIEM. Store state in Azure SQL/PostgreSQL and secrets in Key Vault. Enforce least privilege, peer-reviewed mapping changes, and a manual exception path.
