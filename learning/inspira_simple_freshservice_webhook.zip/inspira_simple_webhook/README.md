# Inspira Financial — Simple Freshservice Onboarding Webhook

## Setup

1. Install Python 3.10+ and `pip install -r requirements.txt`.
2. Set environment variables listed in `.env.example` using a secure secret store (the script does not automatically load `.env`).
3. Start with `uvicorn app:app --host 127.0.0.1 --port 8000` from this directory.
4. Publish behind HTTPS with network access controls, then configure a Freshservice Workflow Automator Web Request to `POST /webhook/onboard`, sending `Content-Type: application/json` and `X-Webhook-Token: <secret>`.
5. Use `sample_request.json` as the request body template, replacing all values with validated Freshservice data.

## Critical production limitations

- This is a **synchronous demonstration**, not an enterprise-grade durable job processor. Freshservice request timeouts can occur; use an async queue and ledger for production.
- A shared webhook secret authenticates the caller but does **not** verify approval. Add server-side Freshservice approval verification before enabling real provisioning.
- `GRAPH_ACCESS_TOKEN` is a manually supplied, short-lived token. Production should acquire Graph tokens using managed identity or a secure OAuth client.
- Configure least-privilege provider credentials, private networking where possible, replay protection, idempotency, and immutable audit records.
- SonarQube endpoint shown targets SonarQube Server and may differ by version. Validate against your deployment.
- Azure DevOps access through Entra groups works only if the groups are properly mapped to Azure DevOps entitlements and permissions.
- GitHub team membership can be `pending` if an invitation needs acceptance. SSO/SCIM-managed organizations may require identity-provider provisioning.
- Avoid exposing detailed provider errors to requesters; production should store internal diagnostics securely.
