"""Inspira Financial - minimal Freshservice provisioning webhook.

Run behind an HTTPS reverse proxy. This example requires trusted upstream approval
verification before requests reach this service; a shared token alone does NOT
prove a Freshservice request was approved.
"""
import logging
import os
from typing import Literal

import requests
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, EmailStr, Field

logging.basicConfig(level=logging.INFO)
log = logging.getLogger('inspira-onboarding')
app = FastAPI(title='Inspira Financial Onboarding')

# Replace these examples with approved group/team mappings.
ROLE_MAP = {
    'azure_devops': {'developer': os.getenv('ADO_DEVELOPER_GROUP_ID', '')},
    'github': {'developer': os.getenv('GITHUB_DEVELOPER_TEAM', '')},
    'sonarqube': {'developer': os.getenv('SONAR_DEVELOPER_GROUP', '')},
}

class User(BaseModel):
    email: EmailStr
    entra_object_id: str | None = None
    github_username: str | None = None
    sonarqube_login: str | None = None

class Application(BaseModel):
    name: Literal['azure_devops', 'github', 'sonarqube']
    role: str = Field(min_length=1)

class RequestPayload(BaseModel):
    request_id: str = Field(min_length=1)
    user: User
    applications: list[Application] = Field(min_length=1, max_length=20)

def api_request(method: str, url: str, *, token: str, json=None, params=None):
    if not token:
        raise RuntimeError('Missing API credential')
    response = requests.request(method, url, headers={'Authorization': f'Bearer {token}', 'Accept': 'application/json'}, json=json, params=params, timeout=15)
    if response.status_code not in (200, 201, 202, 204):
        raise RuntimeError(f'Provider returned HTTP {response.status_code}')
    return response

def provision(user: User, application: Application):
    target = ROLE_MAP[application.name].get(application.role)
    if not target:
        raise ValueError('Role not configured for application')
    if application.name == 'azure_devops':
        if not user.entra_object_id:
            raise ValueError('entra_object_id required')
        # Entra group must already be configured to grant Azure DevOps access.
        group_id = target
        url = f'https://graph.microsoft.com/v1.0/groups/{group_id}/members/$ref'
        api_request('POST', url, token=os.getenv('GRAPH_ACCESS_TOKEN', ''), json={'@odata.id': f'https://graph.microsoft.com/v1.0/directoryObjects/{user.entra_object_id}'})
        return 'granted'
    if application.name == 'github':
        if not user.github_username:
            raise ValueError('github_username required')
        org = os.environ['GITHUB_ORG']
        url = f'https://api.github.com/orgs/{org}/teams/{target}/memberships/{user.github_username}'
        response = api_request('PUT', url, token=os.getenv('GITHUB_TOKEN', ''), json={'role': 'member'})
        return response.json().get('state', 'pending')
    if not user.sonarqube_login:
        raise ValueError('sonarqube_login required')
    base = os.environ['SONARQUBE_URL'].rstrip('/')
    # SonarQube Server API uses HTTP Basic token authentication.
    token = os.getenv('SONARQUBE_TOKEN', '')
    if not token:
        raise RuntimeError('Missing SonarQube token')
    response = requests.post(f'{base}/api/user_groups/add_user', auth=(token, ''), data={'name': target, 'login': user.sonarqube_login}, timeout=15)
    if response.status_code not in (200, 204):
        raise RuntimeError(f'SonarQube returned HTTP {response.status_code}')
    return 'granted'

@app.post('/webhook/onboard')
def onboard(payload: RequestPayload, x_webhook_token: str | None = Header(default=None)):
    import secrets
    expected = os.getenv('FRESHSERVICE_WEBHOOK_TOKEN', '')
    if not expected or not x_webhook_token or not secrets.compare_digest(x_webhook_token, expected):
        raise HTTPException(status_code=401, detail='Unauthorized')
    # IMPORTANT: Configure Freshservice to invoke this endpoint ONLY after approval.
    # For production, independently verify the ticket's approval state via Freshservice API.
    results = []
    for application in payload.applications:
        try:
            status = provision(payload.user, application)
            results.append({'application': application.name, 'role': application.role, 'status': status})
        except (ValueError, RuntimeError, requests.RequestException, KeyError) as exc:
            log.warning('Provisioning failed: request=%s app=%s error=%s', payload.request_id, application.name, type(exc).__name__)
            results.append({'application': application.name, 'role': application.role, 'status': 'failed', 'reason': str(exc)})
    return {'request_id': payload.request_id, 'results': results}
